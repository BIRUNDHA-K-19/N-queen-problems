from flask import Flask, render_template, request

app = Flask(__name__)

def is_safe(board, row, col, n):
    for i in range(row):
        if board[i][col]:
            return False
    i, j = row, col
    while i >= 0 and j >= 0:
        if board[i][j]:
            return False
        i -= 1
        j -= 1
    i, j = row, col
    while i >= 0 and j < n:
        if board[i][j]:
            return False
        i -= 1
        j += 1
    return True

def solve_n_queens_util(board, row, n, solutions):
    if row == n:
        solutions.append([r[:] for r in board])
        return
    for col in range(n):
        if is_safe(board, row, col, n):
            board[row][col] = 1
            solve_n_queens_util(board, row + 1, n, solutions)
            board[row][col] = 0

def solve_n_queens(n):
    board = [[0] * n for _ in range(n)]
    solutions = []
    solve_n_queens_util(board, 0, n, solutions)
    return solutions

@app.route("/", methods=["GET", "POST"])
def index():
    solutions = []
    n = 0
    if request.method == "POST":
        n = int(request.form["n"])
        solutions = solve_n_queens(n)
    return render_template("index.html", solutions=solutions, n=n)

if __name__ == "__main__":
    app.run(debug=True)
